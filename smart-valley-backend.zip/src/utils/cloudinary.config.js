import {v2 as cloudinary} from 'cloudinary';
          
cloudinary.config({ 
  cloud_name: 'dzqvcewvy', 
  api_key: '617346197321264', 
  api_secret: 'POo0DtlY6lDObEr8Oo6qRr0MgBw',
});
export default cloudinary;